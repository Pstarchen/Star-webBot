const STATE_KEY = "runtime.state";
const STATE_VERSION = 2;
const MAX_API_OPERATIONS = 4;
const MAX_MEDIA_ITEMS = 3;
const MAX_REPLY_TEXT_CHARS = 2000;
const MAX_DYNAMIC_RULES = 50;
const MAX_DYNAMIC_APIS = 20;
const MAX_STATE_CHARS = 12000;

function isObject(value) {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

function parseArrayConfig(value, label, sdk) {
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(String(value || "[]"));
    if (!Array.isArray(parsed)) throw new Error("必须是 JSON 数组");
    return parsed;
  } catch (error) {
    sdk.log.error(`${label}配置无效`, error && error.message ? error.message : String(error));
    return null;
  }
}

function parseLines(value) {
  if (Array.isArray(value)) return value.map(String).map((item) => item.trim()).filter(Boolean);
  return String(value || "").split(/[\n,，]+/).map((item) => item.trim()).filter(Boolean);
}

function parseJsonArray(value) {
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(String(value || "[]"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function clamp(value, minimum, maximum, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.max(minimum, Math.min(maximum, number)) : fallback;
}

function cleanContent(value) {
  return String(value || "").replace(/<@!?[^>]+>/g, " ").replace(/\s+/g, " ").trim();
}

function normalizeText(value) {
  return cleanContent(value)
    .toLowerCase()
    .replace(/[\s，。！？、,.!?;；:：'"“”‘’（）()\[\]{}<>《》【】_\-]+/g, "");
}

function bigrams(value) {
  if (value.length < 2) return value ? [value] : [];
  const result = [];
  for (let index = 0; index < value.length - 1; index += 1) result.push(value.slice(index, index + 2));
  return result;
}

function similarity(left, right) {
  if (!left || !right) return 0;
  if (left === right) return 1;
  if (left.includes(right) || right.includes(left)) {
    return 0.8 + (Math.min(left.length, right.length) / Math.max(left.length, right.length)) * 0.2;
  }
  const leftPairs = bigrams(left);
  const rightPairs = bigrams(right);
  const remaining = rightPairs.slice();
  let overlap = 0;
  for (const pair of leftPairs) {
    const index = remaining.indexOf(pair);
    if (index >= 0) {
      overlap += 1;
      remaining.splice(index, 1);
    }
  }
  return leftPairs.length + rightPairs.length ? (2 * overlap) / (leftPairs.length + rightPairs.length) : 0;
}

function trimQuery(value) {
  return String(value || "").replace(/^[\s+＋:：,，|｜-]+|[\s+＋:：,，|｜-]+$/g, "").trim();
}

function readPath(root, path) {
  const denied = new Set(["__proto__", "prototype", "constructor"]);
  const segments = String(path || "")
    .replace(/\[([0-9]+)\]/g, ".$1")
    .replace(/^\./, "")
    .split(".")
    .filter(Boolean);
  let value = root;
  for (const segment of segments) {
    if (denied.has(segment) || value === null || value === undefined || (typeof value !== "object" && typeof value !== "string")) return undefined;
    if (!Object.prototype.hasOwnProperty.call(Object(value), segment)) return undefined;
    value = value[segment];
  }
  return value;
}

function unwrapApiResponse(value) {
  let current = value;
  const payloadKeys = ["data", "result", "content", "text"];
  const metadataKeys = new Set(["code", "status", "success", "message", "msg", "requestId", "request_id"]);
  for (let depth = 0; depth < 3 && isObject(current); depth += 1) {
    const keys = Object.keys(current);
    const payloadKey = payloadKeys.find((key) => Object.prototype.hasOwnProperty.call(current, key));
    if (!payloadKey || (keys.length > 2 && !keys.some((key) => metadataKeys.has(key)))) break;
    const next = current[payloadKey];
    if (next === undefined || next === null || next === "") break;
    current = next;
  }
  return current;
}

function resolveToken(context, rawToken) {
  const token = String(rawToken).trim();
  if (token.startsWith("encode.")) return encodeURIComponent(String(readPath(context, token.slice(7)) ?? ""));
  if (token.startsWith("json.")) return JSON.stringify(readPath(context, token.slice(5)) ?? null);
  if (token === "result") return context.result;
  return readPath(context, token);
}

function renderString(value, context) {
  const source = String(value || "");
  const exact = source.match(/^\{\{\s*([^{}]+?)\s*\}\}$/);
  if (exact) {
    const resolved = resolveToken(context, exact[1]);
    return resolved === undefined ? "" : resolved;
  }
  const moustache = source.replace(/\{\{\s*([^{}]+?)\s*\}\}/g, (_match, token) => {
    const resolved = resolveToken(context, token);
    if (resolved === undefined || resolved === null) return "";
    return typeof resolved === "object" ? JSON.stringify(resolved) : String(resolved);
  });
  const variables = context.variables || {};
  return moustache.replace(/\{([A-Za-z][A-Za-z0-9_.-]*)\}/g, (match, token) => {
    if (token === "rand1-100") return String(1 + Math.floor(Math.random() * 100));
    if (Object.prototype.hasOwnProperty.call(variables, token)) return String(variables[token] ?? "");
    if (token.startsWith("var.")) {
      const stored = readPath(context.vars || {}, token.slice(4));
      return stored === undefined || stored === null ? "" : typeof stored === "object" ? JSON.stringify(stored) : String(stored);
    }
    return match;
  });
}

function renderValue(value, context, depth) {
  if (depth > 12) throw new Error("模板嵌套过深");
  if (typeof value === "string") return renderString(value, context);
  if (Array.isArray(value)) return value.map((item) => renderValue(item, context, depth + 1));
  if (isObject(value)) {
    const result = {};
    for (const key of Object.keys(value)) result[key] = renderValue(value[key], context, depth + 1);
    return result;
  }
  return value;
}

function freshState() {
  return {
    version: STATE_VERSION,
    flags: {},
    overrides: {},
    cooldowns: {},
    flood: {},
    apiRate: {},
    globalApiRate: { start: 0, count: 0 },
    cache: {},
    contexts: {},
    variables: {},
    stats: { messages: 0, matched: 0, apiCalls: 0, apiFailures: 0, blocked: 0, rules: {}, apis: {}, daily: {} },
    dynamicRules: [],
    dynamicApis: [],
    apiEnabled: {},
    activeApiId: "",
    schedules: {},
  };
}

function runtimeState(sdk) {
  const stored = sdk.kv.get(STATE_KEY, null);
  const state = isObject(stored) ? stored : freshState();
  const defaults = freshState();
  for (const key of Object.keys(defaults)) {
    if (state[key] === undefined || (isObject(defaults[key]) && !isObject(state[key]))) state[key] = defaults[key];
  }
  if (!Array.isArray(state.dynamicRules)) state.dynamicRules = [];
  if (!Array.isArray(state.dynamicApis)) state.dynamicApis = [];
  state.version = STATE_VERSION;
  return state;
}

function capObject(record, maximum, dateField) {
  const entries = Object.entries(record || {});
  if (entries.length <= maximum) return;
  entries.sort((left, right) => Number(readPath(left[1], dateField) || left[1] || 0) - Number(readPath(right[1], dateField) || right[1] || 0));
  for (const [key] of entries.slice(0, entries.length - maximum)) delete record[key];
}

function compactState(state, now) {
  for (const [key, entry] of Object.entries(state.cache)) {
    if (!isObject(entry) || Number(entry.expiresAt || 0) <= now) delete state.cache[key];
  }
  for (const [key, entry] of Object.entries(state.contexts)) {
    if (!isObject(entry) || Number(entry.expiresAt || 0) <= now) delete state.contexts[key];
  }
  for (const [key, timestamp] of Object.entries(state.cooldowns)) {
    if (now - Number(timestamp || 0) > 7 * 86400000) delete state.cooldowns[key];
  }
  capObject(state.cache, 20, "createdAt");
  capObject(state.contexts, 20, "updatedAt");
  capObject(state.flood, 50, "start");
  capObject(state.apiRate, 30, "start");
  capObject(state.variables, 20, "updatedAt");
  capObject(state.cooldowns, 80, "");
  capObject(state.stats.rules, 30, "updatedAt");
  capObject(state.stats.apis, 30, "updatedAt");
  capObject(state.stats.daily, 14, "updatedAt");
  state.dynamicRules = state.dynamicRules.slice(-MAX_DYNAMIC_RULES);
  state.dynamicApis = state.dynamicApis.slice(-MAX_DYNAMIC_APIS);
  let serialized = JSON.stringify(state);
  while (serialized.length > MAX_STATE_CHARS && Object.keys(state.cache).length) {
    const key = Object.keys(state.cache).sort((left, right) => Number(state.cache[left].createdAt || 0) - Number(state.cache[right].createdAt || 0))[0];
    delete state.cache[key];
    serialized = JSON.stringify(state);
  }
  while (serialized.length > MAX_STATE_CHARS && Object.keys(state.contexts).length) {
    const key = Object.keys(state.contexts).sort((left, right) => Number(state.contexts[left].updatedAt || 0) - Number(state.contexts[right].updatedAt || 0))[0];
    delete state.contexts[key];
    serialized = JSON.stringify(state);
  }
  if (serialized.length > MAX_STATE_CHARS) {
    state.dynamicRules = state.dynamicRules.slice(-20);
    state.dynamicApis = state.dynamicApis.slice(-10);
  }
}

function saveState(sdk, state, now) {
  compactState(state, now);
  sdk.kv.set(STATE_KEY, state);
}

function dateKey(now) {
  return new Date(now).toISOString().slice(0, 10);
}

function incrementStat(state, field, id, now) {
  if (id) {
    const collection = state.stats[field] || (state.stats[field] = {});
    const current = collection[id] || { count: 0, updatedAt: 0 };
    current.count += 1;
    current.updatedAt = now;
    collection[id] = current;
    return;
  }
  state.stats[field] = Number(state.stats[field] || 0) + 1;
  const day = dateKey(now);
  const daily = state.stats.daily[day] || { count: 0, updatedAt: 0 };
  daily.count += 1;
  daily.updatedAt = now;
  state.stats.daily[day] = daily;
}

function sceneFor(event) {
  const data = event.data || {};
  const type = String(event.type || "");
  if (type === "DIRECT_MESSAGE_CREATE" || (data.guild_id && !data.channel_id && type.includes("DIRECT"))) return "dms";
  if (type.startsWith("GROUP") || data.group_openid || data.group_id) return "group";
  if (data.channel_id || type === "AT_MESSAGE_CREATE" || type === "MESSAGE_CREATE") return "channel";
  return "c2c";
}

function eventTarget(event) {
  const data = event.data || {};
  const author = data.author || {};
  const scene = sceneFor(event);
  if (scene === "group") {
    const openid = data.group_openid || data.group_id;
    return openid ? { type: "group", openid: String(openid) } : null;
  }
  if (scene === "channel") return data.channel_id ? { type: "channel", openid: String(data.channel_id) } : null;
  if (scene === "dms") return data.guild_id ? { type: "dms", openid: String(data.guild_id) } : null;
  const openid = author.user_openid || author.member_openid || author.id || data.user_openid || data.openid;
  return openid ? { type: "c2c", openid: String(openid) } : null;
}

function attachmentInfo(data) {
  const attachments = [];
  const candidates = [data.attachments, data.message && data.message.attachments, data.attachment];
  for (const candidate of candidates) {
    const values = Array.isArray(candidate) ? candidate : candidate ? [candidate] : [];
    for (const item of values) if (isObject(item)) attachments.push(item);
  }
  const imageUrls = [];
  let type = "text";
  for (const item of attachments) {
    const url = String(item.url || item.proxy_url || item.file_url || "");
    const contentType = String(item.content_type || item.type || "").toLowerCase();
    if (contentType.includes("image") || /\.(png|jpe?g|gif|webp)(?:\?|$)/i.test(url)) {
      type = "image";
      if (url) imageUrls.push(url);
    } else if (contentType.includes("audio") || contentType.includes("voice")) type = "audio";
    else if (contentType.includes("video")) type = "video";
    else if (url) type = "file";
  }
  return { attachments, imageUrls, type };
}

function eventContext(event, config, state, now) {
  const data = event.data || {};
  const author = data.author || {};
  const rawContent = String(data.content || "");
  const content = cleanContent(rawContent);
  const scene = sceneFor(event);
  const attachment = attachmentInfo(data);
  const userId = String(author.member_openid || author.user_openid || author.id || data.user_openid || data.openid || "anonymous");
  const nickname = String(author.username || author.name || author.nick || data.member && data.member.nick || "");
  const groupId = String(data.group_openid || data.group_id || data.guild_id || "");
  const groupName = String(data.group_name || data.guild_name || data.guild && data.guild.name || "");
  const mentions = Array.isArray(data.mentions) ? data.mentions : [];
  const atList = mentions.map((item) => String(item && (item.user_openid || item.member_openid || item.id) || "")).filter(Boolean);
  const ownerIds = parseLines(config.ownerIds);
  const adminIds = parseLines(config.adminIds);
  let role = ownerIds.includes(userId) ? "owner" : adminIds.includes(userId) ? "admin" : "member";
  const declaredRole = String(author.role || data.member && data.member.role || "").toLowerCase();
  if (declaredRole === "owner") role = "owner";
  else if (role === "member" && ["admin", "administrator"].includes(declaredRole)) role = "admin";
  const wasAt = /(?:^|_)AT_MESSAGE_CREATE$/.test(String(event.type || "")) || /<@!?[^>]+>/.test(rawContent);
  const time = new Date(now);
  const variables = {
    user: nickname || userId,
    qq: userId,
    group: groupName || groupId,
    gid: groupId,
    msg: content,
    time: `${String(time.getHours()).padStart(2, "0")}:${String(time.getMinutes()).padStart(2, "0")}:${String(time.getSeconds()).padStart(2, "0")}`,
    atall: "<@everyone>",
    atuser: userId === "anonymous" ? "" : `<@${userId}>`,
    message: content,
    qqid: userId,
    nickname: nickname || userId,
    group_id: groupId,
    group_name: groupName,
    is_private: String(scene === "c2c" || scene === "dms"),
    at_list: JSON.stringify(atList),
    img_url: attachment.imageUrls[0] || "",
  };
  return {
    now,
    eventType: String(event.type || ""),
    botId: String(event.botId || ""),
    scene,
    rawContent,
    content,
    userId,
    nickname,
    groupId,
    groupName,
    role,
    wasAt,
    atList,
    imageUrls: attachment.imageUrls,
    attachments: attachment.attachments,
    messageType: content ? "text" : attachment.type,
    variables,
    user: { id: userId, name: nickname || userId, role },
    event: data,
    api: {},
    apiResults: {},
    http: {},
    vars: Object.fromEntries(Object.entries(state.variables).map(([key, entry]) => [key, isObject(entry) ? entry.value : entry])),
    history: [],
    query: content,
    match: {},
  };
}

function listContains(list, value) {
  return !list.length || list.includes(String(value));
}

function inTimeRange(start, end, now) {
  if (!start && !end) return true;
  const current = now.getHours() * 60 + now.getMinutes();
  const toMinutes = (value, fallback) => {
    const match = String(value || "").match(/^(\d{2}):(\d{2})$/);
    return match ? Number(match[1]) * 60 + Number(match[2]) : fallback;
  };
  const first = toMinutes(start, 0);
  const last = toMinutes(end, 1439);
  return first <= last ? current >= first && current <= last : current >= first || current <= last;
}

function ruleAllowed(rule, context, disabledGroups) {
  if (!rule || rule.enabled === false || disabledGroups.includes(String(rule.group || "默认分组"))) return false;
  if (rule.eventType && String(rule.eventType) !== context.eventType) return false;
  if (rule.requireAt && !context.wasAt) return false;
  const conditions = isObject(rule.conditions) ? rule.conditions : {};
  const scenes = Array.isArray(conditions.scenes) ? conditions.scenes.map(String) : [];
  const users = Array.isArray(conditions.userIds) ? conditions.userIds.map(String) : [];
  const userBlacklist = Array.isArray(conditions.userBlacklist) ? conditions.userBlacklist.map(String) : [];
  const groups = Array.isArray(conditions.groupIds) ? conditions.groupIds.map(String) : [];
  const groupBlacklist = Array.isArray(conditions.groupBlacklist) ? conditions.groupBlacklist.map(String) : [];
  const bots = Array.isArray(conditions.botIds) ? conditions.botIds.map(String) : [];
  const roles = Array.isArray(conditions.roles) ? conditions.roles.map(String) : [];
  const messageTypes = Array.isArray(conditions.messageTypes) ? conditions.messageTypes.map(String) : [];
  if (!listContains(scenes, context.scene) || !listContains(users, context.userId) || userBlacklist.includes(context.userId)) return false;
  if (!listContains(groups, context.groupId) || groupBlacklist.includes(context.groupId)) return false;
  if (!listContains(bots, context.botId) || !listContains(roles, context.role) || !listContains(messageTypes, context.messageType)) return false;
  return inTimeRange(conditions.timeStart, conditions.timeEnd, new Date(context.now));
}

function matchTerm(content, term, mode, threshold) {
  const source = String(content || "");
  const keyword = String(term || "").trim();
  if (!keyword) return null;
  const sourceLower = source.toLowerCase();
  const keywordLower = keyword.toLowerCase();
  const normalizedSource = normalizeText(source);
  const normalizedKeyword = normalizeText(keyword);
  if (mode === "regex") {
    try {
      const match = source.match(new RegExp(keyword, "i"));
      return match ? { score: 1, query: trimQuery(match[1] === undefined ? source.replace(match[0], " ") : match[1]) } : null;
    } catch {
      return null;
    }
  }
  if (mode === "contains") {
    const index = sourceLower.indexOf(keywordLower);
    return index >= 0 ? { score: 0.92, query: trimQuery(`${source.slice(0, index)} ${source.slice(index + keyword.length)}`) } : null;
  }
  if (mode === "startsWith") return sourceLower.startsWith(keywordLower) ? { score: 0.96, query: trimQuery(source.slice(keyword.length)) } : null;
  if (mode === "endsWith") return sourceLower.endsWith(keywordLower) ? { score: 0.96, query: trimQuery(source.slice(0, source.length - keyword.length)) } : null;
  if (mode === "fuzzy") {
    const score = similarity(normalizedSource, normalizedKeyword);
    const index = sourceLower.indexOf(keywordLower);
    return score >= threshold ? { score, query: index >= 0 ? trimQuery(source.slice(index + keyword.length)) : source } : null;
  }
  if (normalizedSource === normalizedKeyword) return { score: 1, query: "" };
  if (sourceLower.startsWith(keywordLower) && /^[\s+＋:：,，|｜-]/.test(source.slice(keyword.length))) {
    return { score: 0.99, query: trimQuery(source.slice(keyword.length)) };
  }
  return null;
}

function matchRule(rule, context, defaultThreshold) {
  if (rule.eventType && !context.content && String(rule.eventType) === context.eventType) {
    return { rule, question: String(rule.prefix || rule.eventType), query: "", score: 1 };
  }
  const mode = ["exact", "contains", "regex", "startsWith", "endsWith", "fuzzy"].includes(String(rule.match)) ? String(rule.match) : "exact";
  const threshold = clamp(rule.threshold, 0.1, 1, defaultThreshold);
  const terms = [rule.prefix, ...(Array.isArray(rule.aliases) ? rule.aliases : [])].map(String).filter(Boolean);
  let best = null;
  for (const term of terms) {
    const matched = matchTerm(context.content, term, mode, threshold);
    if (matched && (!best || matched.score > best.score)) best = { rule, question: term, query: matched.query, score: matched.score };
  }
  return best;
}

function findMatches(context, rules, config) {
  const defaultThreshold = clamp(config.fuzzyThreshold, 0.1, 1, 0.6);
  const disabledGroups = parseLines(config.disabledGroups);
  const matches = [];
  for (const rule of rules) {
    if (!ruleAllowed(rule, context, disabledGroups)) continue;
    const matched = matchRule(rule, context, defaultThreshold);
    if (matched) matches.push(matched);
  }
  const matchRank = { exact: 6, startsWith: 5, endsWith: 4, contains: 3, regex: 2, fuzzy: 1 };
  matches.sort((left, right) => Number(right.rule.weight || 50) - Number(left.rule.weight || 50)
    || Number(matchRank[String(right.rule.match || "exact")] || 0) - Number(matchRank[String(left.rule.match || "exact")] || 0)
    || right.score - left.score);
  const strategy = String(config.conflictStrategy || "highest");
  if (strategy === "merge") return matches.slice(0, 3);
  if (strategy === "random" && matches.length) return [matches[Math.floor(Math.random() * matches.length)]];
  return matches.slice(0, 1);
}

function globalFilter(context, config, state) {
  if (config.enabled === false || state.flags.repliesEnabled === false) return { blocked: true, reason: "disabled" };
  if (state.flags.sleeping) return { blocked: true, reason: "sleeping" };
  if (context.scene === "group" && config.allowGroup === false) return { blocked: true, reason: "group_disabled" };
  if (["c2c", "dms"].includes(context.scene) && config.allowPrivate === false) return { blocked: true, reason: "private_disabled" };
  if (context.scene === "channel" && config.allowChannel === false) return { blocked: true, reason: "channel_disabled" };
  const userBlacklist = parseLines(config.userBlacklist);
  const userWhitelist = parseLines(config.userWhitelist);
  const groupBlacklist = parseLines(config.groupBlacklist);
  const groupWhitelist = parseLines(config.groupWhitelist);
  if (userBlacklist.includes(context.userId) || (userWhitelist.length && !userWhitelist.includes(context.userId))) return { blocked: true, reason: "user_list" };
  if (context.groupId && (groupBlacklist.includes(context.groupId) || (groupWhitelist.length && !groupWhitelist.includes(context.groupId)))) return { blocked: true, reason: "group_list" };
  const allowedTypes = parseLines(config.allowedMessageTypes || "text,image,audio,video,file");
  if (allowedTypes.length && !allowedTypes.includes(context.messageType)) return { blocked: true, reason: "message_type" };
  const normalized = context.content.toLowerCase();
  if (parseLines(config.blockedWords).some((word) => normalized.includes(word.toLowerCase()))) return { blocked: true, reason: "blocked_word" };
  if (parseLines(config.sensitiveWords).some((word) => normalized.includes(word.toLowerCase()))) {
    return { blocked: true, reason: "sensitive", reply: String(config.sensitiveReply || "消息包含受保护内容，未调用外部接口。") };
  }
  return { blocked: false };
}

function floodBlocked(context, config, state) {
  const windowSeconds = clamp(config.floodWindowSeconds, 1, 300, 10);
  const maximum = clamp(config.floodMaxActions, 1, 100, 5);
  const key = `${context.botId}:${context.userId}`;
  const current = state.flood[key];
  if (!current || context.now - Number(current.start || 0) >= windowSeconds * 1000) {
    state.flood[key] = { start: context.now, count: 1 };
    return false;
  }
  current.count = Number(current.count || 0) + 1;
  return current.count > maximum;
}

function cooldownRemaining(state, key, seconds, now) {
  if (!seconds) return 0;
  const previous = Number(state.cooldowns[key] || 0);
  return previous && now - previous < seconds * 1000 ? Math.ceil((seconds * 1000 - (now - previous)) / 1000) : 0;
}

function referencedApiIds(rule) {
  const ids = [];
  if (Array.isArray(rule.apis)) {
    for (const id of rule.apis.map(String)) if (id && !ids.includes(id)) ids.push(id);
  }
  const serialized = JSON.stringify(rule.reply === undefined ? rule.answer : rule.reply) || "";
  const pattern = /\{\{?\s*(?:api|http)\.([A-Za-z][A-Za-z0-9_-]*)\b/g;
  let match;
  while ((match = pattern.exec(serialized))) if (!ids.includes(match[1])) ids.push(match[1]);
  return ids.slice(0, 3);
}

function responseType(definition, value, response) {
  const configured = String(definition.responseType || "auto");
  if (configured !== "auto") return configured;
  const contentType = String(response && response.headers && response.headers["content-type"] || "").toLowerCase();
  const url = typeof value === "string" ? value : isObject(value) && typeof value.url === "string" ? value.url : "";
  if (contentType.startsWith("image/") || /\.(png|jpe?g|gif|webp)(?:\?|$)/i.test(url)) return "image";
  if (contentType.startsWith("video/") || /\.(mp4|webm|mov)(?:\?|$)/i.test(url)) return "video";
  if (contentType.startsWith("audio/") || /\.(mp3|wav|ogg|m4a)(?:\?|$)/i.test(url)) return "audio";
  if (/^https?:\/\//i.test(url) && /\.[A-Za-z0-9]{2,8}(?:\?|$)/.test(url)) return "file";
  return "text";
}

function isBinaryResponse(response) {
  const contentType = String(response && response.headers && response.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
  if (!contentType) return false;
  return !contentType.startsWith("text/")
    && contentType !== "application/json"
    && !contentType.endsWith("+json")
    && contentType !== "application/javascript"
    && contentType !== "application/xml"
    && !contentType.endsWith("+xml")
    && contentType !== "application/x-www-form-urlencoded";
}

function cacheKey(definition, context, config) {
  const identity = config.privacyPassIdentifiers === false ? "anonymous" : context.userId;
  return `${definition.id}:${identity}:${context.groupId}:${context.content}`.slice(0, 500);
}

function rateAllowed(state, definition, config, now) {
  const globalLimit = clamp(config.globalApiRatePerMinute, 0, 600, 60);
  if (!state.globalApiRate.start || now - Number(state.globalApiRate.start) >= 60000) state.globalApiRate = { start: now, count: 0 };
  if (globalLimit && Number(state.globalApiRate.count || 0) >= globalLimit) return false;
  const limit = clamp(definition.rateLimitPerMinute, 0, 120, 0);
  const current = state.apiRate[definition.id];
  if (!current || now - Number(current.start || 0) >= 60000) state.apiRate[definition.id] = { start: now, count: 0 };
  if (limit && Number(state.apiRate[definition.id].count || 0) >= limit) return false;
  state.globalApiRate.count += 1;
  state.apiRate[definition.id].count += 1;
  return true;
}

function apiDefinition(definitions, id, state) {
  const definition = definitions.find((item) => item && String(item.id) === String(id));
  if (!definition) throw new Error(`未找到 API 配置：${id}`);
  const override = state.apiEnabled[String(id)];
  if (definition.enabled === false || override === false) throw new Error(`API 已禁用：${id}`);
  return definition;
}

function apiTemplateContext(context, config) {
  const apiContext = {
    ...context,
    config: { starchenApiKey: String(config.starchenApiKey || "") },
  };
  if (config.privacyPassIdentifiers !== false) return apiContext;
  return {
    ...apiContext,
    userId: "",
    groupId: "",
    groupName: "",
    atList: [],
    event: {},
    user: { ...context.user, id: "" },
    variables: {
      ...context.variables,
      qq: "",
      qqid: "",
      gid: "",
      group_id: "",
      group_name: "",
      at_list: "[]",
      atuser: "",
    },
  };
}

async function executeApi(id, definitions, context, sdk, state, config, budget, stack) {
  const definition = apiDefinition(definitions, id, state);
  if (stack.includes(String(id))) throw new Error(`API 链存在循环：${stack.concat(String(id)).join(" -> ")}`);
  if (context.apiResults[id]) return context.apiResults[id];
  const nextStack = stack.concat(String(id));
  const key = cacheKey(definition, context, config);
  const cached = state.cache[key];
  if (cached && Number(cached.expiresAt || 0) > context.now) {
    context.api[id] = cached.value;
    context.http[id] = cached.response;
    const result = { id: String(id), value: cached.value, raw: cached.raw, type: cached.type, response: cached.response, cached: true };
    Object.defineProperty(result, "sourceHeaders", { value: renderValue(definition.headers || {}, apiTemplateContext(context, config), 0), enumerable: false });
    context.apiResults[id] = result;
    if (definition.chainToApiId) return executeApi(definition.chainToApiId, definitions, context, sdk, state, config, budget, nextStack);
    return result;
  }
  const cooldown = clamp(definition.cooldownSeconds, 0, 86400, 0);
  const remaining = cooldownRemaining(state, `api:${id}:${context.userId}`, cooldown, context.now);
  if (remaining) throw new Error(`API ${definition.name || id} 冷却中，还需 ${remaining} 秒`);
  if (!rateAllowed(state, definition, config, context.now)) throw new Error(`API ${definition.name || id} 已达到调用频率限制`);

  const serializedRequest = JSON.stringify({ url: definition.url, headers: definition.headers, body: definition.body });
  if (serializedRequest.includes("{{config.starchenApiKey}}") && !String(config.starchenApiKey || "").trim()) {
    throw new Error("请先在策略与风控中填写 StarChen API Key");
  }
  const templateContext = apiTemplateContext(context, config);
  const renderedUrl = String(renderValue(definition.url, templateContext, 0) || "");
  const options = {
    method: String(definition.method || "GET").toUpperCase(),
    responseMode: String(definition.responseMode || "json") === "media" ? "media" : "json",
    timeoutMs: clamp(definition.timeoutMs, 1000, 25000, 10000),
    headers: renderValue(definition.headers || {}, templateContext, 0),
  };
  if (definition.body !== undefined) options.body = renderValue(definition.body, templateContext, 0);
  const attempts = Math.min(3, 1 + Math.floor(clamp(definition.retryCount, 0, 2, 0)));
  let response = null;
  let lastError = null;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    if (budget.used >= MAX_API_OPERATIONS) throw new Error("本次消息的 API 调用次数已达到上限");
    budget.used += 1;
    incrementStat(state, "apiCalls", null, context.now);
    incrementStat(state, "apis", String(id), context.now);
    try {
      response = await sdk.http.request(renderedUrl, options);
      if (!response || !response.ok) throw new Error(`HTTP ${response ? response.status : "未知"}`);
      lastError = null;
      break;
    } catch (error) {
      lastError = error;
    }
  }
  if (lastError || !response) {
    incrementStat(state, "apiFailures", null, context.now);
    if (definition.fallbackApiId) return executeApi(definition.fallbackApiId, definitions, context, sdk, state, config, budget, nextStack);
    const message = definition.errorMessage || (lastError && lastError.message) || `API ${id} 调用失败`;
    throw new Error(String(message));
  }

  const raw = options.responseMode === "media" ? response.url : response.body;
  let value = definition.responsePath ? readPath(raw, definition.responsePath) : unwrapApiResponse(raw);
  if ((value === undefined || value === null || value === "") && options.responseMode !== "media" && isBinaryResponse(response) && response.url) {
    value = response.url;
  }
  if (value === undefined || value === null || value === "") {
    if (definition.emptyMessage) value = String(definition.emptyMessage);
    else throw new Error(`API ${definition.name || id} 返回空值`);
  }
  context.api[id] = value;
  context.http[id] = response;
  if (definition.responseTemplate) value = renderValue(definition.responseTemplate, { ...context, result: value }, 0);
  context.api[id] = value;
  const type = responseType(definition, value, response);
  const result = { id: String(id), value, raw, type, response, cached: false };
  Object.defineProperty(result, "sourceHeaders", { value: options.headers, enumerable: false });
  context.apiResults[id] = result;
  state.cooldowns[`api:${id}:${context.userId}`] = context.now;
  if (String(definition.cacheSeconds || 0) !== "0") {
    const serialized = JSON.stringify(result);
    if (serialized.length <= 4000) state.cache[key] = { ...result, userId: context.userId, createdAt: context.now, expiresAt: context.now + clamp(definition.cacheSeconds, 0, 86400, 0) * 1000 };
  }
  if (JSON.stringify(value).length <= 2000) state.variables[id] = { value, updatedAt: context.now };
  if (definition.chainToApiId) return executeApi(definition.chainToApiId, definitions, context, sdk, state, config, budget, nextStack);
  return result;
}

function replyDefinition(rule) {
  if (typeof rule.reply === "string") return { text: rule.reply, media: [], format: "text", mention: "none" };
  if (isObject(rule.reply)) return rule.reply;
  return { text: rule.answer === undefined ? "" : String(rule.answer), media: [], format: "text", mention: "none" };
}

function mediaUrl(value) {
  if (typeof value === "string") return value;
  return isObject(value) ? String(value.url || value.file || value.src || "") : "";
}

function resultReply(result) {
  if (!result) return { text: "", media: [], format: "text", mention: "none" };
  if (["image", "video", "audio", "file"].includes(result.type)) {
    return { text: "", media: [{ type: result.type, url: mediaUrl(result.value) || String(result.response && result.response.url || "") }], format: "text", mention: "none" };
  }
  const value = result.value;
  return { text: typeof value === "string" ? value : JSON.stringify(value), media: [], format: "text", mention: "none" };
}

function collectMedia(reply, apiResults, context) {
  const media = Array.isArray(reply.media) ? reply.media.slice() : [];
  for (const result of apiResults || []) {
    const url = mediaUrl(result.value) || String(result.response && result.response.url || "");
    const sourceHeaders = mediaSourceHeaders(result && result.sourceHeaders);
    const existing = url && media.find((item) => String(item && item.url || "") === url);
    if (existing && sourceHeaders) existing._sourceHeaders = sourceHeaders;
    if (!["image", "video", "audio", "file"].includes(result.type)) continue;
    if (url && !existing) media.push({ type: result.type, url, ...(sourceHeaders ? { _sourceHeaders: sourceHeaders } : {}) });
  }
  return media.slice(0, MAX_MEDIA_ITEMS);
}

function mediaFileType(type) {
  if (type === "image") return 1;
  if (type === "video") return 2;
  if (type === "audio" || type === "voice") return 3;
  if (type === "file") return 4;
  return 0;
}

function mediaSourceHeaders(value) {
  if (!isObject(value)) return null;
  return Object.keys(value).length ? value : null;
}

async function sendDirect(sdk, target, payload) {
  if (target.type === "group") return sdk.qq.sendGroup(target.openid, payload);
  if (target.type === "c2c") return sdk.qq.sendC2C(target.openid, payload);
  if (target.type === "channel" && typeof sdk.qq.sendChannel === "function") return sdk.qq.sendChannel(target.openid, payload);
  if (target.type === "dms" && typeof sdk.qq.sendDms === "function") return sdk.qq.sendDms(target.openid, payload);
  const root = target.type === "channel" ? "/channels/" : "/dms/";
  return sdk.qq.request("POST", `${root}${encodeURIComponent(target.openid)}/messages`, payload);
}

function mentionText(text, mention, context) {
  const mode = String(mention || "none");
  if (mode === "sender" && context.variables.atuser) return `${context.variables.atuser} ${text}`.trim();
  if (mode === "all") return `${context.variables.atall} ${text}`.trim();
  return text;
}

function replyText(value) {
  if (value === undefined || value === null) return "";
  if (typeof value === "string") return value.trim();
  if (typeof value === "object") return JSON.stringify(value, null, 2);
  return String(value).trim();
}

function boundedReplyText(value) {
  const text = replyText(value);
  if (text.length <= MAX_REPLY_TEXT_CHARS) return text;
  const suffix = "\n[内容已截断]";
  return text.slice(0, MAX_REPLY_TEXT_CHARS - suffix.length) + suffix;
}

function queueTextReply(sdk, value) {
  const text = boundedReplyText(value);
  if (text) sdk.reply.text(text);
  return text;
}

async function sendReply(event, rawReply, context, sdk, apiResults, targetOverride) {
  const data = event.data || {};
  const reply = isObject(rawReply) ? rawReply : { text: String(rawReply || "") };
  let selectedText = reply.text;
  const variants = Array.isArray(reply.variants) ? reply.variants.map(String).filter((item) => item.trim()) : [];
  if (variants.length) selectedText = variants[Math.floor(Math.random() * variants.length)];
  const rendered = renderValue({ ...reply, text: selectedText }, context, 0);
  const text = boundedReplyText(mentionText(replyText(rendered.text), rendered.mention, context));
  const media = collectMedia(rendered, apiResults, context);
  const format = String(rendered.format || "text");
  if (!media.length) {
    if (format === "markdown" && isObject(rendered.payload)) sdk.reply.markdown(rendered.payload);
    else if (format === "ark" && isObject(rendered.payload)) sdk.reply.ark(rendered.payload);
    else if (text) queueTextReply(sdk, text);
    return Boolean(text || (format !== "text" && rendered.payload));
  }

  const target = targetOverride || eventTarget(event);
  if (!target) {
    if (text) queueTextReply(sdk, text);
    sdk.log.error("无法从事件中识别富媒体回复目标", event.type);
    return Boolean(text);
  }
  let sequence = 1;
  const messageContext = {};
  if (data.id) messageContext.msg_id = String(data.id);
  if (data.event_id) messageContext.event_id = String(data.event_id);
  const channelStyle = target.type === "channel" || target.type === "dms";
  const firstMediaIsImage = channelStyle && String(media[0] && media[0].type || "").toLowerCase() === "image";
  if (text && !firstMediaIsImage) {
    await sendDirect(sdk, target, channelStyle
      ? { content: text, ...messageContext }
      : { content: text, msg_type: 0, msg_seq: sequence, ...messageContext });
    sequence += 1;
  }
  for (let index = 0; index < media.length; index += 1) {
    const item = media[index];
    const typeName = String(item && item.type || "").toLowerCase();
    const type = mediaFileType(typeName);
    const url = String(item && item.url || "");
    if (!type || !/^https?:\/\//i.test(url)) {
      sdk.log.warn("忽略无效的富媒体配置", { type: typeName, hasUrl: Boolean(url) });
      continue;
    }
    if (channelStyle) {
      if (type === 1) {
        const payload = { image: url, ...messageContext };
        const caption = index === 0 && text ? text : item.caption ? String(item.caption) : "";
        if (caption) payload.content = caption;
        await sendDirect(sdk, target, payload);
      } else {
        const caption = item.caption ? `${String(item.caption)}\n` : "";
        await sendDirect(sdk, target, { content: `${caption}${url}`, ...messageContext });
        sdk.log.warn("频道接口不支持 URL 文件上传，已发送公网链接", { type: typeName });
      }
      sequence += 1;
      continue;
    }
    const root = target.type === "group" ? "/v2/groups/" : "/v2/users/";
    const sourceHeaders = mediaSourceHeaders(item && item._sourceHeaders);
    if (sourceHeaders && typeof sdk.qq.uploadMediaFromUrl !== "function") throw new Error("QQ_MEDIA_RELAY_UNAVAILABLE");
    const uploaded = sourceHeaders
      ? await sdk.qq.uploadMediaFromUrl(target.type === "group" ? "group" : "c2c", target.openid, type, url, sourceHeaders)
      : await sdk.qq.request("POST", `${root}${encodeURIComponent(target.openid)}/files`, {
        file_type: type,
        url,
        srv_send_msg: false,
      });
    const fileInfo = uploaded && uploaded.body && uploaded.body.file_info;
    if (!fileInfo) throw new Error("QQ 富媒体上传未返回 file_info");
    const payload = { msg_type: 7, media: { file_info: String(fileInfo) }, msg_seq: sequence, ...messageContext };
    if (item.caption) payload.content = String(item.caption);
    await sendDirect(sdk, target, payload);
    sequence += 1;
  }
  return Boolean(text || media.length);
}

function contextKey(context) {
  return `${context.botId}:${context.scene}:${context.groupId}:${context.userId}`;
}

function loadHistory(context, config, state) {
  if (config.contextEnabled === false) return;
  const entry = state.contexts[contextKey(context)];
  if (entry && Number(entry.expiresAt || 0) > context.now && Array.isArray(entry.messages)) context.history = entry.messages;
}

function rememberConversation(context, config, state, answer) {
  if (config.contextEnabled === false || !answer) return;
  const key = contextKey(context);
  const maximum = Math.floor(clamp(config.contextMaxTurns, 1, 10, 5)) * 2;
  const ttl = clamp(config.contextTtlSeconds, 60, 86400, 1800);
  const current = state.contexts[key] && Array.isArray(state.contexts[key].messages) ? state.contexts[key].messages.slice() : [];
  current.push({ role: "user", content: context.content.slice(0, 500) });
  current.push({ role: "assistant", content: String(answer).slice(0, 500) });
  state.contexts[key] = { messages: current.slice(-maximum), updatedAt: context.now, expiresAt: context.now + ttl * 1000 };
}

function isManager(context) {
  return context.role === "owner" || context.role === "admin";
}

function dynamicRule(prefix, answer) {
  const id = `dynamic_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
  return {
    id,
    name: `指令问答：${prefix}`.slice(0, 80),
    group: "指令新增",
    enabled: true,
    prefix: String(prefix).slice(0, 200),
    aliases: [],
    match: "exact",
    requireAt: false,
    weight: 50,
    cooldownSeconds: 0,
    conditions: {},
    apis: [],
    reply: { text: String(answer).slice(0, 4000), variants: [], media: [], format: "text", mention: "none" },
  };
}

function commandReply(sdk, message) {
  queueTextReply(sdk, message);
}

async function handleCommand(context, config, state, definitions, sdk, budget) {
  const content = context.content;
  const prefix = String(config.commandPrefix || "#");
  if (!content.startsWith(prefix)) return false;
  const command = content.slice(prefix.length).trim();
  if (command === "帮助" || command === "指令列表") {
    commandReply(sdk, "可用指令：#帮助、#指令列表、#清除缓存、#清空对话。管理员还可使用 #新增问答、#删除问答、#查询问答、#添加API、#启用API、#禁用API、#设置默认API、#测试API、#开启/关闭自定义回复、#开启/关闭API兜底、#全局冷却、#机器人休眠/唤醒。");
    return true;
  }
  if (command === "清除缓存") {
    for (const [key, entry] of Object.entries(state.cache)) if (isObject(entry) && String(entry.userId || "") === context.userId) delete state.cache[key];
    commandReply(sdk, "已清除你的 API 缓存。");
    return true;
  }
  if (command === "清空对话") {
    delete state.contexts[contextKey(context)];
    commandReply(sdk, "已清空当前会话上下文。");
    return true;
  }
  if (!isManager(context)) {
    commandReply(sdk, "该指令仅主人或管理员可用。");
    return true;
  }
  if (command.startsWith("新增问答 ")) {
    const pair = command.slice(5).split("||");
    if (pair.length < 2 || !pair[0].trim() || !pair.slice(1).join("||").trim()) throw new Error("格式：#新增问答 触发词||回复内容");
    state.dynamicRules.push(dynamicRule(pair[0].trim(), pair.slice(1).join("||").trim()));
    commandReply(sdk, `已新增问答：${pair[0].trim()}`);
    return true;
  }
  if (command.startsWith("删除问答 ")) {
    const keyword = command.slice(5).trim();
    const before = state.dynamicRules.length;
    state.dynamicRules = state.dynamicRules.filter((rule) => String(rule.prefix) !== keyword);
    commandReply(sdk, before === state.dynamicRules.length ? "未找到通过指令新增的问答。" : `已删除问答：${keyword}`);
    return true;
  }
  if (command.startsWith("查询问答 ")) {
    const keyword = command.slice(5).trim().toLowerCase();
    const found = state.dynamicRules.filter((rule) => String(rule.prefix || "").toLowerCase().includes(keyword)).slice(0, 10);
    commandReply(sdk, found.length ? found.map((rule) => `${rule.prefix} -> ${rule.reply && rule.reply.text || ""}`).join("\n") : "未找到匹配问答。");
    return true;
  }
  if (command === "清空问答") {
    if (context.role !== "owner") throw new Error("仅主人可清空指令新增的问答");
    state.dynamicRules = [];
    commandReply(sdk, "已清空通过指令新增的问答；配置页规则未受影响。");
    return true;
  }
  if (command === "导出问答") {
    const output = JSON.stringify(state.dynamicRules);
    commandReply(sdk, output.length <= 1900 ? output : "问答数据超过消息长度限制，请在配置页的数据管理中导出 JSON。");
    return true;
  }
  if (command.startsWith("导入问答 ")) {
    const imported = JSON.parse(command.slice(5).trim());
    if (!Array.isArray(imported)) throw new Error("导入内容必须是 JSON 数组");
    for (const item of imported.slice(0, MAX_DYNAMIC_RULES)) {
      if (isObject(item) && item.prefix && item.reply) state.dynamicRules.push(item);
    }
    commandReply(sdk, "问答已导入。建议在配置页检查并保存为正式规则。");
    return true;
  }
  if (command.startsWith("添加API ")) {
    const parts = command.slice(6).split("|").map((item) => item.trim());
    if (parts.length < 3 || !/^https?:\/\//i.test(parts[1])) throw new Error("格式：#添加API 名称|url|GET或POST|token=可选");
    const id = `api_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}`;
    const token = parts.slice(3).find((item) => item.startsWith("token="));
    state.dynamicApis.push({
      id,
      name: parts[0].slice(0, 80),
      enabled: true,
      method: parts[2].toUpperCase() === "POST" ? "POST" : "GET",
      responseMode: "json",
      responseType: "auto",
      url: parts[1].slice(0, 2000),
      headers: token ? { Authorization: `Bearer ${token.slice(6)}` } : {},
      cooldownSeconds: 0,
      cacheSeconds: 0,
      timeoutMs: 10000,
      retryCount: 0,
      rateLimitPerMinute: 0,
    });
    commandReply(sdk, `已添加 API：${parts[0]}（ID：${id}）。敏感凭据建议改在配置页维护。`);
    return true;
  }
  const apiToggle = command.match(/^(启用|禁用)API\s+(.+)$/);
  if (apiToggle) {
    const found = definitions.find((item) => String(item.id) === apiToggle[2] || String(item.name) === apiToggle[2]);
    if (!found) throw new Error("未找到指定 API");
    state.apiEnabled[String(found.id)] = apiToggle[1] === "启用";
    commandReply(sdk, `${apiToggle[1]} API：${found.name}`);
    return true;
  }
  if (command.startsWith("设置默认API ") || command.startsWith("切换")) {
    const name = command.startsWith("切换") ? command.slice(2).trim() : command.slice(7).trim();
    const found = definitions.find((item) => String(item.id) === name || String(item.name) === name);
    if (!found) throw new Error("未找到指定 API");
    state.activeApiId = String(found.id);
    commandReply(sdk, `默认 API 已切换为：${found.name}`);
    return true;
  }
  if (command.startsWith("测试API ")) {
    const input = command.slice(6).trim();
    const separator = input.indexOf(" ");
    const name = separator < 0 ? input : input.slice(0, separator);
    const sample = separator < 0 ? "测试" : input.slice(separator + 1);
    const found = definitions.find((item) => String(item.id) === name || String(item.name) === name);
    if (!found) throw new Error("未找到指定 API");
    const previous = context.content;
    context.content = sample;
    context.query = sample;
    context.variables.message = sample;
    context.variables.msg = sample;
    const result = await executeApi(found.id, definitions, context, sdk, state, config, budget, []);
    context.content = previous;
    commandReply(sdk, `API 测试成功（${result.cached ? "缓存" : result.response.status}）：${typeof result.value === "string" ? result.value : JSON.stringify(result.value)}`);
    return true;
  }
  if (command === "开启自定义回复" || command === "关闭自定义回复") {
    state.flags.repliesEnabled = command.startsWith("开启");
    commandReply(sdk, `自定义回复已${command.startsWith("开启") ? "开启" : "关闭"}。`);
    return true;
  }
  if (command === "开启API兜底" || command === "关闭API兜底") {
    state.flags.fallbackEnabled = command.startsWith("开启");
    commandReply(sdk, `API 兜底已${command.startsWith("开启") ? "开启" : "关闭"}。`);
    return true;
  }
  if (command.startsWith("全局冷却 ")) {
    state.overrides.globalCooldownSeconds = Math.floor(clamp(command.slice(5), 0, 86400, 0));
    commandReply(sdk, `全局冷却已设置为 ${state.overrides.globalCooldownSeconds} 秒。`);
    return true;
  }
  if (command === "机器人休眠" || command === "机器人唤醒") {
    state.flags.sleeping = command.endsWith("休眠");
    commandReply(sdk, state.flags.sleeping ? "机器人已休眠；管理员仍可发送唤醒指令。" : "机器人已唤醒。");
    return true;
  }
  return false;
}

function scheduleTarget(schedule) {
  const type = ["group", "c2c", "channel", "dms"].includes(String(schedule.scene)) ? String(schedule.scene) : "group";
  return schedule.targetId ? { type, openid: String(schedule.targetId) } : null;
}

async function handleSchedules(event, context, config, state, definitions, sdk, budget) {
  if (context.eventType !== "STARBOT_SCHEDULE_TICK") return false;
  const schedules = parseJsonArray(config.schedules);
  const timestamp = Number(event.data && event.data.timestamp || context.now);
  for (const schedule of schedules) {
    if (!isObject(schedule) || schedule.enabled === false) continue;
    const offsetMinutes = clamp(schedule.timezoneOffsetMinutes, -720, 840, 480);
    const now = new Date(timestamp + offsetMinutes * 60000);
    const hhmm = `${String(now.getUTCHours()).padStart(2, "0")}:${String(now.getUTCMinutes()).padStart(2, "0")}`;
    const day = now.getUTCDay();
    const date = now.toISOString().slice(0, 10);
    if (String(schedule.time || "") !== hhmm) continue;
    if (Array.isArray(schedule.days) && schedule.days.length && !schedule.days.map(Number).includes(day)) continue;
    const scheduleId = String(schedule.id || `${schedule.time}:${schedule.targetId}`);
    if (state.schedules[scheduleId] === date) continue;
    const target = scheduleTarget(schedule);
    if (!target) continue;
    let result = null;
    if (schedule.apiId) result = await executeApi(String(schedule.apiId), definitions, context, sdk, state, config, budget, []);
    const reply = schedule.text ? { text: String(schedule.text), media: [], format: "text", mention: "none" } : resultReply(result);
    await sendReply(event, reply, context, sdk, result ? [result] : [], target);
    state.schedules[scheduleId] = date;
    sdk.log.info("custom reply schedule sent", { scheduleId, targetType: target.type });
  }
  return true;
}

function logIdentity(context, config) {
  if (config.privacyPassIdentifiers === false) return "hidden";
  return context.userId.length > 8 ? `${context.userId.slice(0, 3)}...${context.userId.slice(-3)}` : context.userId;
}

StarBot.definePlugin({
  async onEvent(event, sdk) {
    const now = Date.now();
    const state = runtimeState(sdk);
    const config = sdk.config || {};
    const apiDefinitions = parseArrayConfig(config.apiDefinitions, "自定义 API", sdk);
    const configuredRules = parseArrayConfig(config.replyRules, "回复规则", sdk);
    if (!apiDefinitions || !configuredRules) return;
    const definitions = apiDefinitions.concat(state.dynamicApis || []);
    const rules = configuredRules.concat(state.dynamicRules || []);
    const context = eventContext(event, config, state, now);
    const budget = { used: 0 };
    incrementStat(state, "messages", null, now);
    loadHistory(context, config, state);

    try {
      const commandHandled = await handleCommand(context, config, state, definitions, sdk, budget);
      if (commandHandled) {
        saveState(sdk, state, now);
        if (config.stopPropagation !== false) sdk.stopPropagation();
        return;
      }
      if (await handleSchedules(event, context, config, state, definitions, sdk, budget)) {
        saveState(sdk, state, now);
        return;
      }
      const filter = globalFilter(context, config, state);
      if (filter.blocked) {
        incrementStat(state, "blocked", null, now);
        if (filter.reply) queueTextReply(sdk, filter.reply);
        saveState(sdk, state, now);
        return;
      }
      if (floodBlocked(context, config, state)) {
        incrementStat(state, "blocked", null, now);
        if (config.floodMessage) queueTextReply(sdk, config.floodMessage);
        saveState(sdk, state, now);
        return;
      }
      const globalCooldown = clamp(state.overrides.globalCooldownSeconds, 0, 86400, clamp(config.globalCooldownSeconds, 0, 86400, 0));
      const globalKey = `global:${context.botId}:${context.userId}`;
      if (cooldownRemaining(state, globalKey, globalCooldown, now)) {
        saveState(sdk, state, now);
        return;
      }

      const matches = findMatches(context, rules, config);
      if (!matches.length) {
        const fallbackEnabled = state.flags.fallbackEnabled === undefined ? config.fallbackEnabled === true : state.flags.fallbackEnabled;
        const defaultApiId = state.activeApiId || String(config.defaultApiId || "");
        if (!fallbackEnabled || !defaultApiId || (["c2c", "dms"].includes(context.scene) && config.privateApiEnabled === false)) {
          saveState(sdk, state, now);
          return;
        }
        const result = await executeApi(defaultApiId, definitions, context, sdk, state, config, budget, []);
        const reply = resultReply(result);
        if (!reply.text && !reply.media.length) reply.text = String(config.fallbackReply || "未获取到可回复内容。");
        const sent = await sendReply(event, reply, context, sdk, [result]);
        if (sent) {
          state.cooldowns[globalKey] = now;
          rememberConversation(context, config, state, reply.text);
          if (config.stopPropagation !== false) sdk.stopPropagation();
        }
        sdk.log.info("custom reply fallback", { apiId: defaultApiId, user: logIdentity(context, config), scene: context.scene, cached: result.cached });
        saveState(sdk, state, now);
        return;
      }

      const replies = [];
      const allResults = [];
      for (const matched of matches) {
        const rule = matched.rule;
        const ruleCooldown = clamp(rule.cooldownSeconds, 0, 86400, 0);
        const ruleKey = `rule:${rule.id}:${context.userId}:${context.groupId}`;
        if (cooldownRemaining(state, ruleKey, ruleCooldown, now)) continue;
        context.query = matched.query;
        context.match = { question: matched.question, score: matched.score, ruleId: String(rule.id || "") };
        const results = [];
        try {
          const apiIds = referencedApiIds(rule);
          if (!context.query && rule.emptyReply && apiIds.length) {
            replies.push({ rule, reply: { text: String(rule.emptyReply), media: [], format: "text", mention: "none" }, results: [] });
            state.cooldowns[ruleKey] = now;
            incrementStat(state, "rules", String(rule.id || "unnamed"), now);
            continue;
          }
          for (const apiId of apiIds) results.push(await executeApi(apiId, definitions, context, sdk, state, config, budget, []));
          const reply = replyDefinition(rule);
          replies.push({ rule, reply, results });
          allResults.push(...results);
          state.cooldowns[ruleKey] = now;
          incrementStat(state, "rules", String(rule.id || "unnamed"), now);
        } catch (error) {
          const errorMessage = error && error.message ? String(error.message) : String(error || "");
          const authFailure = /(?:HTTP\s+(?:401|403)|API\s*Key|鉴权)/i.test(errorMessage);
          const failure = authFailure
            ? "API 鉴权失败，请检查共享 API Key 并保存配置。"
            : String(rule.failureReply || config.apiErrorMessage || errorMessage || "暂时无法获取内容，请稍后再试。");
          replies.push({ rule, reply: { text: failure, media: [], format: "text", mention: "none" }, results: [] });
          sdk.log.error("custom reply API failed", { ruleId: String(rule.id || "unnamed"), message: error && error.message ? error.message : String(error) });
        }
      }
      if (!replies.length) {
        saveState(sdk, state, now);
        return;
      }

      let sent = false;
      if (String(config.conflictStrategy || "highest") === "merge" && replies.length > 1) {
        const texts = replies.map((entry) => {
          const definition = entry.reply;
          const selected = Array.isArray(definition.variants) && definition.variants.length
            ? definition.variants[Math.floor(Math.random() * definition.variants.length)]
            : definition.text;
          return String(renderValue(selected || "", context, 0)).trim();
        }).filter(Boolean);
        const media = replies.flatMap((entry) => collectMedia(renderValue(entry.reply, context, 0), entry.results, context)).slice(0, MAX_MEDIA_ITEMS);
        sent = await sendReply(event, { text: texts.join("\n"), media, format: "text", mention: config.mentionSender === true ? "sender" : "none" }, context, sdk, allResults);
      } else {
        const selected = replies[0];
        const reply = { ...selected.reply };
        if (config.mentionSender === true && (!reply.mention || reply.mention === "none")) reply.mention = "sender";
        sent = await sendReply(event, reply, context, sdk, selected.results);
        const renderedText = renderValue(reply.text || "", context, 0);
        rememberConversation(context, config, state, renderedText);
      }
      if (sent) {
        incrementStat(state, "matched", null, now);
        state.cooldowns[globalKey] = now;
        if (config.stopPropagation !== false) sdk.stopPropagation();
      }
      sdk.log.info("custom reply matched", {
        ruleIds: replies.map((entry) => String(entry.rule.id || "unnamed")),
        strategy: String(config.conflictStrategy || "highest"),
        user: logIdentity(context, config),
        scene: context.scene,
        apiCalls: budget.used,
      });
      saveState(sdk, state, now);
    } catch (error) {
      incrementStat(state, "apiFailures", null, now);
      const errorMessage = error && error.message ? String(error.message) : String(error || "");
      const errorDetails = {
        message: errorMessage,
        ...(error && Number.isInteger(Number(error.status)) ? { status: Number(error.status) } : {}),
        ...(error && error.traceId ? { traceId: String(error.traceId) } : {}),
        ...(error && error.qqCode ? { qqCode: String(error.qqCode) } : {}),
        ...(error && error.qqDetail ? { qqDetail: String(error.qqDetail) } : {}),
        ...(error && error.qqStage ? { qqStage: String(error.qqStage) } : {}),
        user: logIdentity(context, config),
        scene: context.scene,
      };
      sdk.log.error("custom reply failed", errorDetails);
      const qqFailure = /QQ API|QQ 富媒体|QQ 媒体/i.test(errorMessage);
      queueTextReply(sdk, errorMessage === "QQ_MEDIA_RELAY_UNAVAILABLE"
        ? "当前 StarBot 宿主不支持鉴权媒体中转，请更新宿主后重试。"
        : qqFailure
        ? "API 已返回，但 QQ 媒体发送失败，请检查 QQ 媒体地址是否为无需鉴权的公网 URL。"
        : (config.apiErrorMessage || "暂时无法获取内容，请稍后再试。"));
      saveState(sdk, state, now);
    }
  },
});
