# 自定义回复 2.1.6

StarBot 托管插件，用于在 QQ 单聊、群聊和频道中维护本地问答、自定义外部 API、富媒体回复、事件规则、定时推送、上下文和运行数据。插件自带完整配置页面，不需要手写清单或配置 JSON。

## 安装与更新

可导入 ZIP 的根目录必须直接包含：

```text
starbot.plugin.json
index.js
config.html
README.md
```

项目根目录另外提供 `starchen-api-bundle.json`，它是配置页可直接导入的功能包，不需要打进插件 ZIP 才能使用。

在 StarBot 的“插件中心 -> 开发者中心”导入 ZIP。插件 ID 固定为 `custom-reply`；再次导入同一 ID、但版本号更高的包会创建新版本。已安装实例可直接选择新版本更新，不需要先卸载，兼容的旧配置和运行记录会保留。

配置页顶部会显示“已保存”或“有未保存更改”。修改表格、弹窗或策略后，需要点击顶部“保存配置”；保存成功后按钮会重新禁用。媒体上传、运行记录和动态数据属于安装实例数据，会立即写入宿主，不依赖配置保存按钮。

## 配置页面

| 工作区 | 用途 |
| --- | --- |
| 概览 | 查看规则、API、定时任务、运行状态和高频统计 |
| 问答库 | 分页、搜索、分组、批量删除和完整规则编辑 |
| API 池 | 配置请求、在线测试、返回解析、缓存、重试、备用和链式 API |
| 策略与风控 | 冲突策略、冷却、黑白名单、过滤词、上下文、管理员和定时任务 |
| 运行日志 | 查看最近运行状态、事件、耗时、动作数、日志和错误 |
| 数据与媒体 | JSON/CSV 导入导出、动态规则转正式规则、统计清理和持久媒体管理 |

配置页运行在宿主提供的沙箱 iframe 中，不能直接 `fetch`、读取 Cookie、LocalStorage 或父页面 DOM。保存配置、测试 API、读取日志和上传媒体都通过 `window.StarBotConfig` 与宿主通信。

## 问答匹配

每条规则可配置主触发词和最多 20 个别名。匹配时忽略英文大小写；精准和模糊比较还会忽略常见空格及中英文标点。

| 模式 | 行为 | 示例 |
| --- | --- | --- |
| 完全匹配 `exact` | 内容与触发词一致；也接受 `触发词 + 分隔符 + 参数` | `天气`、`天气+北京` |
| 包含匹配 `contains` | 内容任意位置包含触发词 | `帮我查一下天气` |
| 正则匹配 `regex` | 使用不区分大小写的 JavaScript 正则；第一个捕获组作为参数 | `^天气\s+(.+)$` |
| 开头匹配 `startsWith` | 内容以触发词开头，后半段作为参数 | `翻译 hello` |
| 结尾匹配 `endsWith` | 内容以触发词结尾，前半段作为参数 | `北京天气` |
| 模糊匹配 `fuzzy` | 按标准化文本的包含关系和二元组相似度计算 | `今天天汽怎么样` |

模糊阈值范围为 `0.1-1`，越高越严格；单条规则阈值优先于全局阈值。规则还能同时限定：

- 指定 QQ 事件、必须 @ 机器人、私聊/群聊/频道/频道私信场景；
- 用户、群和机器人 ID 白名单或黑名单；
- 主人、管理员、普通成员角色；
- 文本、图片、音频、视频、文件消息类型；
- 支持跨零点的每日时间段；
- 规则分组、启用状态、冷却秒数和权重 `1-100`。

匹配结果先按权重排序，再按匹配模式、分数和配置顺序排序。多条规则同时命中时可选择：只发送最高权重、合并回复、或从最高权重候选中随机一条。

## 回复内容

规则可发送普通文本、Markdown、Ark，以及图片、视频、音频和文件。文本支持多个随机候选；媒体可填写网络 URL，也可先在“数据与媒体”上传本地文件，再使用宿主生成的公网 URL。

单聊和群聊中的媒体流程为：

1. 插件调用 `/v2/users/{openid}/files` 或 `/v2/groups/{openid}/files` 上传公网 URL。
2. QQ 返回 `file_info`。
3. 插件使用 `msg_type: 7` 发送媒体消息。

如果媒体 API 请求本身需要 `Authorization` 或其他请求头，2.1.6 会让 StarBot 服务端先带请求头下载到临时文件，再走同一套 QQ 分片上传流程；请求头不会发送给 QQ，也不会写入日志。该能力需要宿主支持 `sdk.qq.uploadMediaFromUrl`。

`file_type` 对应关系：图片 `1`、视频 `2`、语音 `3`、普通文件 `4`。频道图片使用频道消息的 `image` 字段；QQ 当前未公开频道视频、音频和文件的 `/files` 上传端点，因此这些类型在频道中会退化为公网链接并写入警告日志。

规则 schema 最多保存 5 个媒体项；为控制单次动作数，运行时最多发送前 3 个。媒体 URL 必须是 QQ 服务器无需 Cookie 即可访问的公网 HTTP/HTTPS 地址，不能填写 Windows 路径、Docker 内路径、localhost 或内网地址。

## 自定义 API

最多配置 50 个 API。每项支持：

- GET/POST、URL、最多 20 个自定义请求头和 JSON 请求体；
- 启用状态、接口冷却、每分钟限频和全局限频；
- `1000-25000ms` 超时、最多 2 次重试、失败备用 API；
- `0-86400` 秒缓存、链式下一 API；
- JSON 路径提取、自动/文本/图片/视频/音频/文件结果类型；
- 返回模板、空值话术和错误话术。

### JSON API

接口返回 JSON 时使用 `responseMode: "json"`，并设置返回路径或在模板中直接引用字段：

```json
{
  "id": "weather",
  "name": "天气",
  "enabled": true,
  "method": "GET",
  "responseMode": "json",
  "responsePath": "data.forecast[0]",
  "responseType": "text",
  "responseTemplate": "{{query}}：{{result.text}}，{{result.temperature}}℃",
  "url": "https://api.example.com/weather?city={{encode.query}}",
  "headers": {},
  "cooldownSeconds": 0,
  "cacheSeconds": 600,
  "timeoutMs": 10000,
  "retryCount": 1,
  "rateLimitPerMinute": 20
}
```

路径支持点号和数组下标，例如 `data.content`、`list[0].url`。如果 `responsePath` 已提取 `data.forecast[0]`，模板中的 `{{result.*}}` 以该对象为根。未填写返回路径时，运行时会自动解包常见的 `data`、`result`、`content` 或 `text` 包装层；仍不符合时再为该接口单独设置返回路径。

### 直接返回媒体的 API

如果请求地址本身最终返回图片、视频或音频二进制，选择“媒体文件 URL”，即 `responseMode: "media"`：

```json
{
  "id": "video",
  "name": "随机视频",
  "enabled": true,
  "method": "GET",
  "responseMode": "media",
  "responseType": "video",
  "url": "https://api.example.com/video?keyword={{encode.query}}",
  "headers": {},
  "cooldownSeconds": 0,
  "cacheSeconds": 300,
  "timeoutMs": 15000,
  "retryCount": 1,
  "rateLimitPerMinute": 10
}
```

宿主会验证请求和重定向，但不会把二进制文件读入 QuickJS。最终公网地址位于 `{{api.video.url}}`。规则可以把 API 加入“调用 API”，将结果类型设为视频并自动发送；也可以在媒体 URL 中明确填写 `{{api.video.url}}`。

如果接口返回的是 JSON，例如：

```json
{ "code": 0, "data": { "url": "https://cdn.example.com/a.mp4" } }
```

应保持 `responseMode: "json"`，返回路径填写 `data.url`，结果类型选择“视频”；或在规则媒体 URL 中填写 `{{api.video.data.url}}`。把 JSON 接口错误设为“媒体文件 URL”会得到错误地址或空值，是显示“暂时无法获取内容，请稍后再试”的常见原因。

### POST 和请求头

```json
{
  "id": "chat",
  "name": "对话服务",
  "enabled": true,
  "method": "POST",
  "responseMode": "json",
  "responsePath": "data.answer",
  "responseType": "text",
  "url": "https://api.example.com/chat",
  "headers": {
    "content-type": "application/json",
    "authorization": "Bearer your-token"
  },
  "body": {
    "message": "{message}",
    "user": "{qqid}",
    "history": "{{history}}"
  },
  "cooldownSeconds": 1,
  "cacheSeconds": 0,
  "timeoutMs": 20000,
  "retryCount": 0,
  "rateLimitPerMinute": 30
}
```

请求头会随安装配置保存在宿主数据库中。对于长期密钥，推荐调用自己的服务端代理，由代理通过环境变量持有密钥，避免密钥出现在插件包、导出文件、截图或日志中。

`starchen-api-bundle.json` 中的 26 个 StarChen API 默认共用 `{{config.starchenApiKey}}` 模板。你也可以在每个 API 的请求头直接填写 `Authorization: Bearer ...`，这种方式不需要设置全局 Key；功能包本身不包含真实密钥，运行日志也不会输出请求头。完整 JSON 导出会包含当前配置值，备份文件应按密钥文件保护。

### 备用与链式调用

- `fallbackApiId`：当前 API 请求失败、非 2xx 或解析失败时改用备用 API。
- `chainToApiId`：当前 API 成功后继续调用下一 API；下一 API 可通过 `{{api.<前一ID>...}}` 使用前一结果。
- 单次事件最多执行 4 个 API 操作；循环引用会被拒绝。
- 相同 API、提问和用户可按 `cacheSeconds` 复用，缓存和频率状态按安装实例隔离。

## 模板变量

单花括号用于兼容变量，双花括号支持对象路径和类型保留。只有一个双花括号变量占满整个字段时，会保留数字、布尔、数组或对象类型；嵌入普通文本时会转为字符串。

| 变量 | 内容 |
| --- | --- |
| `{user}` / `{nickname}` | 发送者昵称，缺失时使用 OpenID |
| `{qq}` / `{qqid}` | 发送者 OpenID |
| `{group}` / `{group_name}` | 群或频道名称 |
| `{gid}` / `{group_id}` | 群、频道私信会话等目标 ID |
| `{msg}` / `{message}` | 清理机器人 @ 后的消息文本 |
| `{time}` | 宿主当前时间 `HH:mm:ss` |
| `{rand1-100}` | 1 到 100 的随机整数 |
| `{atall}` / `{atuser}` | 全体 @ / 提问人 @ 标记 |
| `{is_private}` | 是否为单聊或频道私信，字符串 `true/false` |
| `{at_list}` | 被 @ 用户 ID 的 JSON 数组文本 |
| `{img_url}` | 用户消息中的第一张图片 URL |
| `{{query}}` | 匹配后提取的参数 |
| `{{message}}` | 当前清理后的消息 |
| `{{user.id}}` / `{{user.role}}` | 用户 ID 和插件判定角色 |
| `{{event.<path>}}` | QQ 原始事件数据字段 |
| `{{api.<id>.<path>}}` | 某 API 的原始或解析结果字段 |
| `{{http.<id>.status}}` | API HTTP 状态和响应元数据 |
| `{{history}}` | 当前用户的多轮上下文数组 |
| `{var.<name>}` | API 写入的安装实例临时变量 |
| `{{encode.<path>}}` | URL 编码后的值 |
| `{{json.<path>}}` | JSON 序列化后的对象或数组 |

模板可用于 API URL、请求头、JSON 请求体、返回模板、回复文本和媒体 URL。关闭“允许 API 携带用户与群标识”后，身份类兼容变量会在外部 API 模板中脱敏。

## 指令

默认前缀为 `#`。普通用户可使用：

```text
#帮助
#指令列表
#清除缓存
#清空对话
```

主人和管理员还可使用：

```text
#新增问答 触发词||回复内容
#删除问答 触发词
#查询问答 关键词
#导出问答
#导入问答 [JSON数组]
#添加API 名称|https://example.com/api|GET
#启用API API名称或ID
#禁用API API名称或ID
#设置默认API API名称或ID
#切换 API名称或ID
#测试API API名称或ID 测试文本
#开启自定义回复 / #关闭自定义回复
#开启API兜底 / #关闭API兜底
#全局冷却 10
#机器人休眠 / #机器人唤醒
```

只有主人可执行 `#清空问答`。指令新增的数据保存在受限运行状态中；可在配置页把动态问答转换为正式规则后保存。不要通过聊天指令发送真实 Token，优先在配置页或服务端代理维护。

## 事件与定时任务

清单订阅 `"*"`，因此插件能处理宿主已经收到的所有 QQ Dispatch。规则可填写 `eventType`，在没有文本的事件（例如入群、退群或加好友）上触发，再通过 `{{event.<path>}}` 引用载荷。能否收到事件仍取决于 QQ 机器人类型、开放平台权限、Gateway Intent 或 Webhook 配置；插件清单不会替你开通官方权限。

常见消息事件：

| 事件 | 场景 | 主要目标字段 |
| --- | --- | --- |
| `C2C_MESSAGE_CREATE` | QQ 单聊 | `author.user_openid` |
| `GROUP_AT_MESSAGE_CREATE` | 群内 @ 机器人 | `group_openid` |
| `GROUP_MESSAGE_CREATE` | 群全量消息 | `group_openid` |
| `AT_MESSAGE_CREATE` | 公域频道 @ 机器人 | `channel_id` |
| `MESSAGE_CREATE` | 私域频道全量消息 | `channel_id` |
| `DIRECT_MESSAGE_CREATE` | 频道私信 | `guild_id` |

定时任务由当前持有机器人 Gateway 租约的宿主实例按分钟产生 `STARBOT_SCHEDULE_TICK`。只有配置中存在启用任务时插件才会执行。任务支持星期、`HH:mm`、UTC 分钟偏移、目标场景、目标 OpenID、固定文本和一个 API；同一任务同一天只发送一次。机器人离线或宿主未持有 Gateway 租约时不会补发错过的任务。

## 数据、导入导出和媒体

- “导出完整 JSON”包含正式规则、API、策略和 StarChen API Key，可用于替换式备份或迁移。
- 带 `_importMode: "merge"` 的功能包 JSON 按 ID 追加或更新 API/问答；若包内含 `settings`，会同步应用其中列出的必要开关，但不会导入密钥、未知字段或删除其他问答。重复导入不会产生重复项。
- CSV 使用 UTF-8 BOM，可直接由 Excel 打开；别名、条件、媒体、API 引用、载荷等复杂字段以 JSON 单元格保存，导入时追加到问答库。以 `= + - @` 开头的单元格会做 Excel 公式保护并在回导时还原。
- JSON 或 CSV 导入只修改页面中的待保存配置；确认顶部显示“有未保存更改”后，必须点击“保存配置”才会生效。
- `runtime.state` 保存动态规则、缓存、上下文、统计、临时变量和定时去重状态。
- 运行时 KV 每个安装实例最多 100 个 key，单值最大 16KB，总量最大 128KB；插件将主要运行状态压缩在一个 key 内。
- 持久媒体单文件最大 20MB，允许 JPG/PNG/GIF/WebP、MP3/WAV/OGG/M4A、MP4/WebM、PDF、ZIP、TXT 和二进制文件。
- 卸载安装实例会同时删除该实例的持久媒体；更新插件版本不会删除配置、KV、日志或媒体。

在 Docker 中应把宿主数据目录或 `PLUGIN_ASSET_DIRECTORY` 挂载到持久卷，否则重建容器后文件会随容器层消失。

### 导入 StarChen 全功能包

1. 打开插件配置页的“数据与媒体”，点击“导入文件”，选择项目根目录的 `starchen-api-bundle.json`。
2. 导入结果应显示 API 新增/更新 26 项、问答新增/更新 26 项和必要设置 10 项；已有同 ID 项会直接更新，不需要逐条编辑。
3. 打开“策略与风控”，填写一次 `StarChen API Key`。26 个接口共用该值，不需要逐 API 填写请求头。
4. 点击页面顶部“保存配置”。从旧功能包升级时也应重新导入此文件，以更新错误地址、缺参数提示和回复模板。
5. 在“API 池”任选一项在线测试，或发送 `天气+北京`、`随机电脑壁纸`、`MCJava+服务器地址` 等触发词验证。

平台端点、计费和返回结构可能随发布状态变化，功能包依据 [StarChen 接入文档](https://api.starchen.top/docs) 当前公开的 26 个端点生成。运行时会自动解包常见响应包装；若某个接口采用特殊结构，仍可在 API 池中为该项补充 `responsePath` 或返回模板。

## 风控和限制

- 用户/群全局黑白名单、规则级黑白名单和停用分组；
- 屏蔽词静默忽略，敏感词阻止外部 API 并返回本地提示；
- 单用户滑动窗口防刷屏、全局冷却、规则冷却、API 冷却和限频；
- 私聊、群聊、频道分别开关，私聊可单独禁止外部 API；
- 多轮上下文按机器人、场景、群和用户隔离，可设置 `60-86400` 秒和 `1-10` 轮；
- 日志默认只记录截断后的身份，不应记录完整请求头、Token 或敏感响应。

宿主外部 HTTP 层还会拒绝 URL 凭据、localhost、内网/保留地址、危险请求头、超大请求/响应，以及重定向到内网。请求体最大 32KB，JSON/文本响应最大 64KB，最多 3 次重定向。

## 常见问题

### 显示 `PLUGIN_CONFIG_TYPE:apiDefinitions`

通常表示导入了旧结构、手工 JSON 含多余字段、下拉框把未选择的备用/链式 API 保存为空字符串，或数字字段超出范围。2.1.6 配置页会省略空的 `fallbackApiId` 和 `chainToApiId`。在“API 池”逐项打开并保存，仍失败时先导出 JSON，检查错误对应的 API。

### 显示 `PLUGIN_RUNTIME_OUTPUT_INVALID:Invalid input`

旧版本可能把超过宿主 2000 字符限制的 API JSON 直接放入回复动作，或在 API 失败后丢失已生成的错误提示。2.1.6 会先解包常见响应、兼容二进制直链的最终 URL、支持服务端媒体中转、截断超长文本，并使用实际计算后的成功/失败回复。更新插件版本后需要重新导入 `starchen-api-bundle.json` 并保存配置。

### 显示“暂时无法获取内容，请稍后再试”

依次检查：

1. 在 API 编辑器中使用“在线测试”，查看 HTTP 状态、最终 URL、响应体和提取值。
2. 二进制媒体接口选择 `media`；返回 JSON 地址的接口选择 `json` 并填写正确的 `responsePath`。
3. 确认超时不低于接口实际耗时，接口未返回 401/403/404/429/5xx。
4. 确认返回路径大小写正确，数组路径使用 `list[0].url`。
5. 在未登录浏览器或公网机器直接打开媒体 URL，确认不是 HTML 页面、短期 Cookie 地址或内网地址。
6. 在“运行日志”查看 `PLUGIN_HTTP_*`、模板解析、QQ 上传错误和 QQ Trace ID。

### 页面显示“有未保存更改”但找不到按钮

保存按钮固定在配置页顶栏右侧；窄屏时位于顶栏操作区。若宿主仍加载旧配置页，请确认安装实例已经选择 2.1.6 版本并刷新页面，而不是删除插件重装。

### 插件包校验失败

不要把外层目录一起压缩。使用宿主 SDK 构建脚本，它会保证清单和入口位于 ZIP 根目录，并检查大小、文件数量与路径。

## 本地验证与构建

在插件目录执行：

```powershell
node --test .plugin.test.mjs
node ..\star-webBot\sdk\plugin\build.mjs . .\dist\custom-reply-2.1.6.zip
```

宿主仓库可进一步验证类型、测试和生产构建：

```powershell
npx tsc --noEmit
npm test
npm run build
```

QQ API 行为和事件字段以 [QQ 机器人 API v2 官方文档](https://bot.q.qq.com/wiki/develop/api-v2/) 为准。
